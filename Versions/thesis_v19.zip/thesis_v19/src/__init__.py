"""
visibility_path_planning - A package for visibility-based path planning.
"""